# hashCode19
Repo for the 2019 Google HashCode

## Collaborators

[Aitor Arnaiz del Val](https://github.com/arnaizaitor)  
[Adrian Fernandez Amador](https://github.com/afernandez97)  
[David Garcia Fernandez](https://github.com/DavidGarciaFer)  
[Santiago Gonzalez-Carvajal Centenera](https://github.com/santigc6)  
